#!/bin/perl -w
use strict;
# scripted by YuanJQ
my $fastq_dir = "original";
my $fq1_tail = "_1\.clean\.fq";
my $fq2_tail = "_2.clean.fq";
my $genome = "genome.fasta";
my $smrna_sf = `which sortmerna`; chomp $smrna_sf; $smrna_sf =~ s/sortmerna$//;
#my $trinity_dir = "/home/Jiaqing/anaconda3/envs/Trinity/bin";
my $trinity_dir;
$trinity_dir = `which Trinity`; chomp $trinity_dir; $trinity_dir =~ s/Trinity$//;
my $main = `pwd`; chomp $main;
my $work_dir = "$main/out.tmp/3.pasa"; unless(-e $work_dir){system("mkdir -p $work_dir")}
my $intron_max;
chdir $work_dir;
##

# step0: predeal fastq
my $fq_deal = "0.fq_deal";unless(-e $fq_deal){system("mkdir -p $fq_deal");}
unless(-e "0.fq_deal.ok"){
	opendir(FQ, "$main/$fastq_dir") or die $!; my @fq_files = grep(/$fq1_tail$/, readdir(FQ)); close FQ;
	chdir $fq_deal; my $pwd = `pwd`; print STDERR "PWD: $pwd";
	## step0.0: (optional)
	
	## step0.1: perform fastp to deal redudences
	my $fastp_dir = "0.1.fastp";unless(-e $fastp_dir){system("mkdir -p $fastp_dir");}
	unless(-e "0.1.fastp.ok"){
		chdir $fastp_dir; $pwd = `pwd`; print STDERR "PWD: $pwd";		
		my $para_fp = "0.1.para_fastp.txt";
		open(PA, ">$para_fp") or die $!;
		foreach my $fq1 (sort @fq_files){
			my $out1 = "fastp.".$fq1;
			my $fq2 = $fq1; $fq2 =~ s/$fq1_tail$/$fq2_tail/; my $out2 = "fastp.".$fq2;
			my $cmd = "fastp -i $main/$fastq_dir/$fq1 -o $out1 -I $main/$fastq_dir/$fq2 -O $out2";
			#system("$cmd") == 0 or die $!;
			print PA "$cmd\n";
		}close PA;
		system("ParaFly -c $para_fp -CPU 64") == 0 or die $!;
		chdir "../";		
		open(OUT, ">0.1.fastp.ok"); close OUT;
	}

	## step0.2: perform sortmerna to remove the potential rna contamination
	opendir(FQ, $fastp_dir) or die $!; my @fp_files = grep(/$fq1_tail$/, readdir(FQ)); close FQ;
	my $sortmerna_dir = "0.2.sortmerna";unless(-e $sortmerna_dir){system("mkdir -p $sortmerna_dir");}
	unless(-e "0.2.sortmerna.ok"){
		chdir $sortmerna_dir; $pwd = `pwd`; print STDERR "PWD: $pwd";		
		my $para_smrna = "0.2.para_sortmerna.txt";
		open(PA, ">$para_smrna") or die $!;
		foreach  my $fq1 (sort @fp_files){
			my $fq2 = $fq1;$fq2 =~ s/$fq1_tail$//;my $comb = $fq2.".reads_interleaved.fq";$fq2 =$fq2.$fq2_tail;
			my $cmd1 = "$smrna_sf/scripts/merge-paired-reads.sh ../0.1.fastp/$fq1 ../0.1.fastp/$fq2 $comb";
			my $match = "match.".$comb; my $unmatch = "unmatch.".$comb;
			
			my $fa1 = "rfam-5.8s-database-id98.fasta"; my $idx1 = "rfam-5.8s-db";
			my $fa2 = "rfam-5s-database-id98.fasta"; my $idx2 = "rfam-5s-db";
			my $fa3 = "silva-arc-16s-id95.fasta"; my $idx3 = "silva-arc-16s-db";
			my $fa4 = "silva-arc-23s-id98.fasta"; my $idx4 = "silva-arc-23s-db";
			my $fa5 = "silva-bac-16s-id90.fasta"; my $idx5 = "silva-bac-16s-db";
			my $fa6 = "silva-bac-23s-id98.fasta"; my $idx6 = "silva-bac-23s-db";
			my $fa7 = "silva-euk-18s-id95.fasta"; my $idx7 = "silva-euk-18s-db";
			my $fa8 = "silva-euk-28s-id98.fasta"; my $idx8 = "silva-euk-28s-db";

			my $pr1 = "./rRNA_databases/$fa1,./index/$idx1"; my $pr2 = "./rRNA_databases/$fa2,./index/$idx2"; 
			my $pr3 = "./rRNA_databases/$fa3,./index/$idx3"; my $pr4 = "./rRNA_databases/$fa4,./index/$idx4"; 
			my $pr5 = "./rRNA_databases/$fa5,./index/$idx5"; my $pr6 = "./rRNA_databases/$fa6,./index/$idx6"; 
			my $pr7 = "./rRNA_databases/$fa7,./index/$idx7"; 
			#my $pr8 = "./rRNA_databases/$fa8,./index/$idx8"; 
			chomp($pwd);
			my $cmd2 = "cd $smrna_sf && sortmerna --ref $pr1:$pr2:$pr3:$pr4:$pr5:$pr6:$pr7 --reads $pwd/$comb --num_alignments 1 --fastx --aligned $pwd/$match --other $pwd/$unmatch --log -a 8 -m 24000 --paired_in -v && cd $pwd";
			my $unmerge1 = "sortmerna.".$fq1; my $unmerge2 = "sortmerna.".$fq2;
			my $cmd3 = "$smrna_sf/scripts/unmerge-paired-reads.sh $pwd/$unmatch.fq $unmerge1 $unmerge2";
			#system("$cmd1 && $cmd2 && $cmd3") == 0 or die $!;
			print PA "$cmd1 && $cmd2 && $cmd3\n";
		}close PA;
		system("ParaFly -c $para_smrna -CPU 64") == 0 or die $!;
		chdir "../";
		open(OUT, ">0.2.sortmerna.ok"); close OUT;
	}
	chdir $work_dir;	
	open(OUT, ">0.fq_deal.ok"); close OUT;
}



# step1: assembly [denovo(trinity) and genome index(genome_index && trintiy)]
## step1: denovo_trinity
my $denovo_trinity = "1.denovo_trinity";unless(-e $denovo_trinity){system("mkdir -p $denovo_trinity");}
opendir(SMR, "$fq_deal/0.2.sortmerna") or die $!; my @smrna_fqs = grep(/$fq1_tail$/, readdir(SMR));close SMR;
unless(-e "1.denovo_trinity.ok"){
	chdir $denovo_trinity; my $pwd = `pwd`; print STDERR "PWD: $pwd";
	
	## step1.2: denovo_trinity
	my $trinity = "1.1.trinity"; unless(-e $trinity){system("mkdir -p $trinity");}
	unless(-e "1.1.trinity.ok"){
		chdir $trinity; $pwd = `pwd`; print STDERR "PWD: $pwd";
		my $para_trinity = "1.1.para_trinity.txt";
		open(PA, ">$para_trinity") or die $!;	
		foreach  my $fq1 (sort @smrna_fqs){
			my $fq_index = $fq1; $fq_index =~ s/$fq1_tail$//;
			my $fq2 = $fq_index."$fq2_tail";
			my $in_fq1 = "$work_dir/$fq_deal/0.2.sortmerna/$fq1";
			my $in_fq2 = "$work_dir/$fq_deal/0.2.sortmerna/$fq2";
			my $out_dir = "Trinity_".$fq1;
			my $cmd1 = "Trinity --seqType fq --left $in_fq1 --right $in_fq2 --output $out_dir --CPU 16 --max_memory 100G";
			my $cmd2 = "perl $trinity_dir/get_longest_isoform_seq_per_trinity_gene.pl ./$out_dir/Trinity.fasta > $out_dir/$fq_index.longest.trinity.fei.fasta";
			#system("$cmd1 && $cmd2") == 0 or die $!;
			print PA "$cmd1 && $cmd2\n";
		}close PA;
		system("ParaFly -c $para_trinity -CPU 64") == 0 or die $!;
		system("cp ./Trinity_*/*.longest.trinity.fei.fasta ./") == 0 or die $!;
		#system("cat ./Trinity_*/*.longest.trinity.fei.fasta >all.combined.genes") == 0 or die $!;
		chdir "../";
		open(OUT, ">1.1.trinity.ok"); close OUT;
	}
	
	## step1.2: cd-hit-est, remove the repeat ones
	opendir(TRI, "./$trinity") or die "$!";my @tri_dir = grep(/\.longest\.trinity\.fei\.fasta$/, readdir(TRI)); close TRI;
	my $cd_hit = "1.2.cd_hit"; unless(-e $cd_hit){system("mkdir -p $cd_hit");}
	my $n_c = 0.9; my $c_n = 7;
	#my $cdhit_o = "4.2.cd-hit-est".".n_0.95.c_10"; #-n 10, 11 for thresholds 0.95 ~ 1.0-n 8,9 for thresholds 0.90 ~ 0.95-n 7 for thresholds 0.88 ~ 0.9-n 6 for thresholds 0.85 ~ 0.88-n 5 for thresholds 0.80 ~ 0.85-n 4 for thresholds 0.75 ~ 0.8
	unless(-e "1.2.cdhit.ok"){
		chdir $cd_hit;
		foreach my $tri (sort @tri_dir){
			my $org = $tri; $org =~ s/\.longest\.trinity\.fei\.fasta$//;
			my $trifa_o = $org.".fasta";
			open(TRIFA_I, "../$trinity/$tri") or die "$!";
			open(TRIFA_O, ">$trifa_o") or die "$!";
			while(my $line = <TRIFA_I>){
				chomp($line);
				if($line =~ m/^>/){
					$line =~ s/^>//; $line = ">".$org."_".$line;
				}
				print TRIFA_O "$line\n";
			}close TRIFA_I; close TRIFA_O;
		}
		system("cat ./sortmerna*.fasta > all.trans.trinity.fasta") == 0 or die $!;
		my $cmd = "cd-hit-est -i ./all.trans.trinity.fasta -o ./Trinity.cdhitest.fasta -d 0 -c $n_c -n $c_n -M 100000 -T 80";
		system("$cmd") == 0 or die $!;
		chdir "../";
		open(OUT, ">1.2.cdhit.ok"); close OUT;
	}
	
	chdir $work_dir;
	open(OUT, ">1.denovo_trinity.ok"); close OUT;
}


## step1: genome index and trinity
my $ge_tri = "1.genome_trinity";unless(-e $ge_tri){system("mkdir -p $ge_tri");}
unless(-e "1.genome_trinity.ok"){
	chdir $ge_tri; my $pwd = `pwd`; print STDERR "PWD: $pwd";

	### step1.1: genome_index
	my $g_index = "1.1.genome_index"; unless(-e $g_index){system("mkdir -p $g_index");}
	unless(-e "1.1.genome.index.ok"){
		system("STAR --runThreadN 50 --runMode genomeGenerate --genomeDir ./1.1.genome_index --genomeFastaFiles $main/$genome") == 0 or die $!;
		open(OUT, ">1.1.genome.index.ok"); close OUT;
	}
	
	### step1.2: genome guaid ###
	my $g_trinity = "1.2.genome_guaid"; unless(-e $g_trinity){system("mkdir -p $g_trinity");}
	unless(-e "1.2.genome.guaid.ok"){
		chdir $g_trinity; my $pwd = `pwd`; print STDERR "PWD: $pwd";
		#my $para_guaid = "1.2.para_ge_guaid.txt";
		#open(PA, ">$para_guaid") or die $!;
		foreach my $fq1 (sort @smrna_fqs){
			my $fq2 = $fq1; $fq2 =~ s/$fq1_tail$/$fq2_tail/; 
			my $fq_index = $fq1; $fq_index =~ s/$fq1_tail$//;
			print "$fq1\t$fq2\t$fq_index\n";			
			system("mkdir -p $fq_index && chmod -R 755 $fq_index");# 
			my $cmd = "STAR --genomeDir $work_dir/$ge_tri/1.1.genome_index --runThreadN 8 --readFilesIn $work_dir/$fq_deal/0.2.sortmerna/$fq1 $work_dir/$fq_deal/0.2.sortmerna/$fq2 --outFileNamePrefix $fq_index --outSAMtype BAM SortedByCoordinate --outBAMsortingThreadN 20 --outSAMstrandField intronMotif --outFilterMultimapNmax 5 --outFilterMismatchNmax 4 --outFilterMismatchNoverLmax 0.05 --alignIntronMax $intron_max --alignMatesGapMax 1000 --outFilterIntronMotifs RemoveNoncanonical";
			system("$cmd") == 0 or die $!;
			#print PA "$cmd\n";
		}
		#close PA;
		#system("ParaFly -c $para_guaid -c CPU 8") == 0 or die $!;
		chdir "../";
		open(OUT, ">1.2.genome.guaid.ok"); close OUT;
	}
	
	### step1.3: trinity
	my $trinity = "1.3.trinity"; unless(-e $trinity){system("mkdir -p $trinity");}
	opendir(FQ, $g_trinity) or die $!; my @guaid_fqs = grep(/Aligned\.sortedByCoord\.out\.bam$/, readdir(FQ)); close FQ;
	unless(-e "1.3.trinity.ok"){
		chdir $trinity; $pwd = `pwd`; print STDERR "PWD: $pwd";
		my $para_trinity = "1.3.para_trinity.txt";
		open(PA, ">$para_trinity") or die $!;	
		foreach my $fq (sort @guaid_fqs){
			my $fq_index = $fq; $fq_index =~ s/Aligned\.sortedByCoord\.out\.bam$//;
			my $out_dir = "Trinity_".$fq_index;
			my $cmd1 = "Trinity --genome_guided_bam ../$g_trinity/$fq --output $out_dir --genome_guided_max_intron $intron_max --CPU 16 --max_memory 100G";## 内含子长度需要对近缘物种进行检查
			my $cmd2 = "perl $trinity_dir/get_longest_isoform_seq_per_trinity_gene.pl $out_dir/Trinity-GG.fasta > $out_dir/$fq_index.longest.trinity.fei.fasta";
			#system("$cmd1 && $cmd2") == 0 or die $!;
			print PA "$cmd1 && $cmd2\n";
		}close PA;
		system("ParaFly -c $para_trinity -CPU 64") == 0 or die $!;
		system("cp ./Trinity_*/*.longest.trinity.fei.fasta ./") == 0 or die $!;
		#system("cat ./Trinity_*/*.longest.trinity.fei.fasta >all.combined.genes") == 0 or die $!;
		chdir "../";
		open(OUT, ">1.3.trinity.ok"); close OUT;
	}
	
	## step1.4: cd-hit-est, remove the repeat ones
	opendir(TRI, $trinity) or die "$!";my @tri_dir = grep(/\.longest\.trinity\.fei\.fasta$/, readdir(TRI)); close TRI;
	my $cd_hit = "1.4.cd_hit"; unless(-e $cd_hit){system("mkdir -p $cd_hit");}
	my $n_c = 0.9; my $c_n = 7;
	#my $cdhit_o = "4.2.cd-hit-est".".n_0.95.c_10"; #-n 10, 11 for thresholds 0.95 ~ 1.0-n 8,9 for thresholds 0.90 ~ 0.95-n 7 for thresholds 0.88 ~ 0.9-n 6 for thresholds 0.85 ~ 0.88-n 5 for thresholds 0.80 ~ 0.85-n 4 for thresholds 0.75 ~ 0.8
	unless(-e "1.4.cdhit.ok"){
		chdir $cd_hit; my $pwd = `pwd`; print STDERR "PWD: $pwd";
		foreach (sort @tri_dir){
			my $org = $_; $org =~ s/\.longest\.trinity\.fei\.fasta$//;
			my $trifa_o = $org.".fasta";
			open(TRIFA_I, "../$trinity/$_") or die "$!";
			open(TRIFA_O, ">$trifa_o") or die "$!";
			while(my $line = <TRIFA_I>){
				chomp($line);
				if($line =~ m/^>/){
					$line =~ s/^>//; $line = ">".$org."_".$line;
				}
				print TRIFA_O "$line\n";
			}close TRIFA_I; close TRIFA_O;
		}
		system("cat ./sortmerna*.fasta > all.trans.trinity.fasta") == 0 or die $!;
		my $cmd = "cd-hit-est -i ./all.trans.trinity.fasta -o ./Trinity.cdhitest.fasta -d 0 -c $n_c -n $c_n -M 100000 -T 100";
		system("$cmd") == 0 or die $!;
		chdir "../";
		open(OUT, ">1.4.cdhit.ok"); close OUT;
	}

	chdir $work_dir;
	open(OUT, ">1.genome_trinity.ok"); close OUT;
}


# step2: pasa main
my $pasa = "2.pasa";unless(-e $pasa){system("mkdir -p $pasa");}
unless(-e "2.pasa.ok"){
	chdir $pasa; my $pwd = `pwd`; print STDERR "PWD: $pwd";
	
	## step2.1: prepare pasa
	## need DBI:mysql:db 模块 
	#my $pasa_path = "/DATA_DISK/yuanjq/biosoft_shared/PASApipeline.v2.4.1";
	my $pasa_path = `which pasa`; chomp $pasa_path; $pasa_path =~ s/\/bin\/pasa$//;
	my $univec = "/DATADISK/yuanjq/biosoft_shared/gene_prediction/UniVec/UniVec";
	
	system("cp $pasa_path/pasa_conf/alignAssembly.config ./");
	unless(-e "2.1.prepare"){system("mkdir 2.1.prepare");}
	unless(-e "2.1.prepare.pasa.ok"){
		chdir "2.1.prepare";
		#system("cp ../../$denovo_trinity/1.2.cd_hit/Trinity.cdhitest.fasta ./Trinity.fasta") == 0 or die $!;
		system("cp ../../$ge_tri/1.4.cd_hit/Trinity.cdhitest.fasta ./Trinity.fasta") == 0 or die $!; # change this into genome guide
=pod		
		system("cat Trinity.fasta Trinity.GG.fasta >transcripts.fasta") == 0 or die $!;
		system("perl $pasa_path/misc_utilities/accession_extractor.pl < Trinity.fasta > tdn.accs") == 0 or die $!;
		system("perl $pasa_path/Launch_PASA_pipeline.pl -c ../alignAssembly.config -t transcripts.fasta -C -R -g $main/$genome --ALIGNERS blat,gmap --CPU 64 --TDN tdn.accs") == 0 or die $!;
		system("$pasa_path/scripts/build_comprehensive_transcriptome.dbi -c ../alignAssembly.config -t transcripts.fasta --min_per_ID 95 --min_per_aligned 30") == 0 or die $!;
=cut		
		chdir "../";
		open(OUT, ">2.1.prepare.pasa.ok") or die $!;
	}
	
	## step2.2: perform pasa
	# change this part to your own data
	my $tri_fas = "Trinity.fasta";
	my $mysql_db = "muskrat_pasa";
	my $spe = "muskrat";
	
	unless(-e "2.2.pasa"){system("mkdir -p 2.2.pasa");}
	unless(-e "2.2.pasa.ok"){
		chdir "2.2.pasa";

		## step 1: do the seqclean; 
		unless(-e "2.2.clean.ok"){
			system("cp $univec ./");
			system("formatdb -i UniVec -p F -o T");
			system("cp ../2.1.prepare/Trinity.fasta ./");
			system("$pasa_path/bin/seqclean $tri_fas -c 16 -v $univec") ==0 or die $!; 
			#system("$pasa_path/bin/seqclean $tri_fas");
			open(OUT, ">2.2.clean.ok"); close OUT;
		}
		## step 2;
		#system("perl $pasa_path/Launch_PASA_pipeline.pl -c ../alignAssembly.config -C -R -g $main/$genome -t $tri_fas.clean -T -u $tri_fas --ALIGNERS blat,gmap --CPU 16") ==0 or die $!;
		system("perl $pasa_path/Launch_PASA_pipeline.pl -c ../alignAssembly.config -C -R -g $main/$genome -t $tri_fas.clean -I $intron_max -T -u $tri_fas --ALIGNERS gmap,blat --CPU 16") ==0 or die $!;# you can use one of the blat or gmap
		## step3;
		system("$pasa_path/scripts/pasa_asmbls_to_training_set.dbi --pasa_transcripts_fasta $mysql_db.assemblies.fasta --pasa_transcripts_gff3 $mysql_db.pasa_assemblies.gff3") ==0 or die $!;
		
		chdir "../";
		open(OUT, ">2.2.pasa.ok"); close OUT;
	}
	
	chdir $work_dir;
	open(OUT, ">2.pasa.ok"); close OUT;
}