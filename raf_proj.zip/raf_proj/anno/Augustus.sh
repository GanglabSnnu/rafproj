#!/usr/bin/bash
seqkit split -i genome.masked.fasta
find genome.masked.fasta.split -type f -name "*.fasta" | parallel -j 32 augustus --species=human --AUGUSTUS_CONFIG_PATH=/home/Jiaqing/biosoftwares/gene_anno/gene_structure/denovo/augustus.2.5.5/config --gff3=on >> temp.gff 
join_aug_pred.pl < temp.gff  | grep -v '^#' > temp.joined.gff
bedtools sort -i temp.joined.gff > RAF.augustus.gff