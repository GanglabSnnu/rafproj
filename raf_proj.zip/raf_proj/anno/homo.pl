#!/bin/perl
use strict;
# scritped by YuanJQ

my $main = `pwd`; chomp $main;
my $gemoma_jar = "/home/yjq/biosoftwares/gene_anno/gene_structure/homo/genoma-1.8/GeMoMa-1.8.jar";
my $evm_dir = "/home/yjq/biosoftwares/gene_anno/gene_structure/all_pipes/EVidenceModeler-1.1.1";
my $busco_dir = "/home/yjq/anaconda3/lib/python3.8/site-packages/busco";
my $database_dir = "/home/yjq/biosoftwares/quality_assess/busco_database";
my $mam = "mammalia_odb10";
my $vert = "vertebrata_odb10";
my $database = $mam;

my $genome = "$main/../genome.fasta";
my $genome_dir = "/data-storage/Public/yjq/annotation/Ursus_thibetanus/original/aall_abbr_genome";
my $gff_dir = "/data-storage/Public/yjq/annotation/Ursus_thibetanus/original/aall_cut_gffs";
my $search_engine = "mmseqs"; ## or mmseqs
my $para_run = "20";
##

opendir(DIR, $genome_dir) or die "$!"; my @genomes = grep(/fna$/, readdir(DIR)); close DIR;
print "step1: gemoma.performing!\n";
unless(-e "1.gemoma.ok"){
	foreach my $ref_genome (@genomes){
		my $gff_cut = $ref_genome; $gff_cut =~ s/\.fna$/.gff.100.cut/;
		my $out_dir = $ref_genome;
		print "$gff_cut\t$out_dir\n";
		unless(-e "$main/$out_dir"){system("mkdir -p $main/$out_dir");}
		
		opendir(GFFCUT, "$gff_dir/$gff_cut") or die $!; my @cuts = grep(/gff$/, readdir(GFFCUT)); close GFFCUT;
		my @sorted = sort(@cuts); 
		
		open(PA, ">para.$out_dir.gemoma.txt") or die "$!";
		foreach my $each (@sorted){
			my $out = "out.".$each;
			my $cmd = "$main/run.sh $search_engine $genome $main/$gff_dir/$gff_cut/$each $main/$genome_dir/$ref_genome $main/$out_dir/$out";
			if($search_engine eq "mmseqs"){
				print PA "$cmd && rm $main/$out_dir/$out/mmseqsdb && rm -r $main/$out_dir/$out/ref >$main/$out_dir/out.log 2>&1\n";
			}
			if($search_engine eq "tblastn"){
				print PA "$cmd && rm $main/$out_dir/$out/blastdb.nsq && rm $main/$out_dir/$out/search.txt >$main/$out_dir/out.log 2>&1\n";
			}
		}
		close PA;
		system("ParaFly -c para.$out_dir.gemoma.txt -CPU $para_run");		
	}
	open(OUT, ">1.gemoma.ok") or die $!; close OUT;
}


print "step2: combind.gemoma.results!\n";
unless(-e "2.combine.ok"){
	foreach my $each (@genomes){
		#$each =~ s/.genomic\.fna$//; 
		print "$each\n";
		chdir "$each";
		my $out = $each.".gff";
		system("cat ./out.round.*.gff/final_annotation.gff >./$out") == 0 or die $!;
#		chdir "../";
		
		#unless(-e "combined.all.gff3"){system("cat ./*.gff >combined.all.gff3");}
		system("java -jar $gemoma_jar CLI GAF g=./$out outdir=./") == 0 or die $!;
		system("java -jar $gemoma_jar CLI AnnotationFinalizer g=$genome a=filtered_predictions.gff outdir=./ rename=NO") == 0 or die $!;
		my $cp_rename = $each."_final_annotation.gff3";
		system("cp ./final_annotation.gff ../$cp_rename") == 0 or die $!;
		
		chdir "..";		
	}
	open(OUT, ">2.combine.ok") or die $!; close OUT;
}

print "step3: filter.gemoma.results!\n";
unless(-e "3.combine_filter.ok"){
	unless(-e "combined.all.gff3"){system("cat ./*final_annotation.gff3 >combined.all.gff3") == 0 or die $!;}
	system("java -jar $gemoma_jar CLI GAF g=./combined.all.gff3 outdir=./") == 0 or die $!;
	system("java -jar $gemoma_jar CLI AnnotationFinalizer g=$genome a=filtered_predictions.gff outdir=./ rename=NO") == 0 or die $!;
	open(OUT, ">3.combine_filter.ok") or die $!; close OUT;	
}

print "step4: rename.gemoma!\n";
opendir(GEM, $main) or die $!; my @gemomas_gff = grep(/\.genomic\.fna_final_annotation\.gff3$/, readdir(GEM)); close GEM;
unless(-e "4.standard.evminput.ok"){
	foreach my $each (sort @gemomas_gff){
		my $abbr = $each; $abbr =~ s/\.genomic\.fna\_final\_annotation\.gff3$//;
		my $gem_evm = $abbr.".GeMoMa.evm.gff3";
		print "gem2evm: $gem_evm\n";
		system("perl $evm_dir/EvmUtils/misc/GeMoMa_gff_to_gff3.pl $each >$gem_evm") == 0 or die $!;
		my $rename_evm = $gem_evm.".standard";
		open(IN, "$gem_evm") or die $!;
		open(OUT, ">$rename_evm") or die $!;
		while(my $line = <IN>){
			chomp $line;
			my @arr = split /\t/, $line;
			next if $line !~ /^\S+/;
			print OUT "$arr[0]\tGM$abbr\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\n";
		}close IN; close OUT;
		
		unless(-e "$abbr.busco"){system("mkdir -p $abbr.busco");}
		chdir "$abbr.busco";
		system("gffread ../$gem_evm -g $genome -y $abbr.pep.fasta") == 0 or die $!;
		# if busco installed with conda
		system("nohup python $busco_dir/run_BUSCO.py -m proteins -i $abbr.pep.fasta -l $database_dir/$database -o out_put &");
		chdir "..";
	}

	#combined final gemoma annotation
	system("perl $evm_dir/EvmUtils/misc/GeMoMa_gff_to_gff3.pl final_annotation.gff >final.GeMoMa.evm.gff3.standard") == 0 or die $!;	
	unless(-e "gemoma.busco"){system("mkdir -p gemoma.busco");
		chdir "gemoma.busco";
		system("gffread ../final.GeMoMa.evm.gff3.standard -g $genome -y gemoma.pep.fasta") == 0 or die $!;
		# if busco installed with conda
		system("nohup python $busco_dir/run_BUSCO.py -m proteins -i gemoma.pep.fasta -l $database_dir/$database -o out_put &");
		chdir "..";
	}
	
	open(OUT, ">4.standard.evminput.ok") or die $!; close OUT;	
}

