#!/usr/bin/perl
use strict;
# scripted by YuanJq
## conda activate comp_ana


my $main = `pwd`; chomp $main;
my @species = ("BTA","FCA","HAR","MMO","MMY","PDI","PKU","RAE","RAF","RFE");#change this part with your own species!
my $spe_num = $#species + 1; 
#my $spe_num = scalar @species;
my $ref = "BTA,FCA";
my @postive_selection_branch = ("RAF","RH","R");# change this part with your own positive selection branches
my $cafe_tut = "/DATADISK/yuanjq/biosoft_shared/CAFE";
my $astral = "/home/Jiaqing/biosoftwares/phylogeny/ASTRAL-5.7.1/Astral/astral.5.7.1.jar";
my $cpu = "16";
my $orth_cpu = 5*$cpu;

# step 1.0: run orthofinder
print "step 1.0: run orthofinder\n";
my $pep_dir = "./0.genomic_data/pep"; #change this part with your own pep directory!
my $cds_dir = "./0.genomic_data/cds"; #change this part with your own cds directory!
my $orth_work = "./1.orthologs"; # add this variable, the orthofinder will auto produced!
unless(-e "$orth_work/0.orthofinder.ok"){
	system("orthofinder -f $pep_dir -M msa -a $orth_cpu -o ./$orth_work") == 0 or die $!;
	open(OUT, ">$orth_work/0.orthofinder.ok") or die "$!";
	close OUT;
}

# step 1.1: select single_copy genes
print "step 1.1: select single_copy genes\n";
unless(-e "$orth_work/1.single_copy.ok"){
	system("perl ./scripts/1.select.unique.pl $orth_work/Results_*/Orthogroups/Orthogroups_SingleCopyOrthologues.txt $orth_work/single.copy.genes.txt $orth_work/Results_*/Orthogroups/Orthogroups.tsv") == 0 or die $!;
	open(OUT, ">$orth_work/1.single_copy.ok") or die "$!";
	close OUT;
}

# step 2.0: split pep with single_copy gene sets
print "step 2.0: split pep with single_copy gene sets\n";
my $align_dir = "2.gene_align";
unless(-e "$align_dir"){system(mkdir "$align_dir");}
unless(-e "$align_dir/2.gene_align.ok"){
	system("perl ./scripts/2.split_protein_for_run_prank.pl $pep_dir $orth_work $align_dir $orth_cpu") == 0 or die $!; # prank mafft, muscle 
	open(OUT, ">$align_dir/2.gene_align.ok") or die "$!";
	close OUT;
}

# step 3: construct tree
print "step 3: construct tree\n";
my $construct_tree = "3.phylogenetic_tree";
unless(-e "$construct_tree"){system("mkdir $construct_tree");}
unless(-e "$construct_tree/3.constuct_tree.ok"){
	my $trimal_dir = "3.0.0.trimal_pep"; unless(-e "$construct_tree/$trimal_dir"){system("mkdir -p $construct_tree/$trimal_dir")}
	my $trimal_filter = "3.0.1.trimal_pep_filter"; unless(-e "$construct_tree/$trimal_filter"){system("mkdir -p $construct_tree/$trimal_filter")}
	system("perl ./scripts/3.0.0.trimal_filter_pep.pl $construct_tree $align_dir $trimal_dir $trimal_filter $spe_num $cpu") == 0 or die $!;
	
	my $pep_mer = "3.0.pep_merged"; unless(-e "$construct_tree/$pep_mer"){system("mkdir -p $construct_tree/$pep_mer")}
	system("perl ./scripts/3.0.merge_singlecopygenes_phy.pl $trimal_filter $construct_tree $pep_mer @species") == 0 or die $!;
	unless(-e "$construct_tree/3.0.pepmerged.const.ok"){
	chdir "$construct_tree/$pep_mer";
		#system("nohup raxmlHPC-PTHREADS-AVX -T 32 -f a -N 100 --bootstop-perms=1000 -m PROTGAMMAWAG -x 12345 -p 12345 -o $ref -s merged.aln.phy -n merged.aln.nwk &");#protein
		system("nohup raxmlHPC-PTHREADS-AVX -T 32 -f a -N 100 --bootstop-perms=1000 -m PROTGAMMAWAG -x 12345 -p 12345 -o $ref -s trim.merged.aln.phy -n trim.merged.aln.nwk &") == 0 or die $!;#protein
		chdir "../../";
		open(MPC, ">$construct_tree/3.0.pepmerged.const.ok") or die "$!";
		close MPC;
	}
	
	my $pep_phy = "3.1.aligned_pep_phy"; unless(-e "$construct_tree/$pep_phy"){system("mkdir -p $construct_tree/$pep_phy");}
	system("perl ./scripts/3.1.pep_phy.pl $construct_tree $trimal_filter $pep_phy @species") == 0 or die $!;
	
	unless(-e "$construct_tree/3.1.split_pep.const.ok"){
		opendir(PEPP, "$construct_tree/$pep_phy") or die "$!";my @pep_phys = grep(/phy/, readdir(PEPP)); close PEPP;
		my $out_tree = "3.1.out_pep_tree"; unless(-e "$construct_tree/$out_tree"){system("mkdir -p $construct_tree/$out_tree");}
		chdir "$construct_tree/$out_tree";
		open(PA_PC, ">../parafly_run.construct.pep.txt") or die "$!";		
		foreach my $each (sort @pep_phys){
			my $out = $each; $out =~ s/\.phy$/.nwk/;
			print PA_PC "raxmlHPC-PTHREADS-AVX -T 1 -f a -N 100 --bootstop-perms=1000 -m PROTGAMMAWAG -x 12345 -p 12345 -o $ref -s \"../$pep_phy/$each\" -n $out\n";
		}
		system("nohup ParaFly -c ../parafly_run.construct.pep.txt -CPU $cpu &");
		chdir "../../";
		open(MPC, ">$construct_tree/3.1.split_pep.const.ok") or die "$!";
		close MPC;
	}
	
	unless(-e "$construct_tree/3.2.split_pep.const_noroot.ok"){ ## noroot tree, and for anstral
		opendir(PEPP, "$construct_tree/$pep_phy") or die "$!";my @pep_phys = grep(/phy/, readdir(PEPP)); close PEPP;
		my $out_tree = "3.2.out_pep_tree_noroot"; unless(-e "$construct_tree/$out_tree"){system("mkdir -p $construct_tree/$out_tree");}
		chdir "$construct_tree/$out_tree";
		open(PA_PC, ">../parafly_run.construct_noroot.pep.txt") or die "$!";		
		foreach my $each (sort @pep_phys){
			my $out = $each; $out =~ s/\.phy$/.nwk/;
			print PA_PC "raxmlHPC-PTHREADS-AVX -T 1 -f a -N 100 --bootstop-perms=1000 -m PROTGAMMAWAG -x 12345 -p 12345 -s \"../$pep_phy/$each\" -n $out\n";
		}
		system("nohup ParaFly -c ../parafly_run.construct_noroot.pep.txt -CPU $cpu && cat RAxML_bestTree.* >../combined.all.tree.txt && java -jar $astral -r 1000 -i ../combined.all.tree.txt -o ../all_pep_astral.nwk &") == 0 or die $!;
		
		chdir "../../";
		open(MPC, ">$construct_tree/3.2.split_pep.const_noroot.ok") or die "$!";
		close MPC;
	}
	
	open(OUT, ">$construct_tree/3.constuct_tree.ok") or die "$!";
	close OUT;
}

#=pod
# step 4: prepare for positive selection
print "step 4: prepare for positive selection\n";
my $pos_selection = "4.pre_ps";
unless(-e "$pos_selection"){system("mkdir $pos_selection");}
unless(-e "$pos_selection/4.prepare.ps.ok"){
	my $ps_dir1 = "4.0_CDS_format"; unless(-e "$pos_selection/$ps_dir1"){system("mkdir -p $pos_selection/$ps_dir1");}
	system("perl ./scripts/4.0.format.cds.pl $cds_dir $pos_selection $ps_dir1");
	
	my $ps_dir2 = "4.1_CDS_unalgin"; unless(-e "$pos_selection/$ps_dir2"){system("mkdir -p $pos_selection/$ps_dir2");}
	system("perl ./scripts/4.1.split_cds.pl $cds_dir $orth_work $pos_selection $spe_num");

	my $ps_dir3 = "4.2_CDS_match"; unless(-e "$pos_selection/$ps_dir3"){system("mkdir -p $pos_selection/$ps_dir3");}
	system("perl ./scripts/4.2.match_AA_NU_Prank.pl $pos_selection $ps_dir2 $align_dir $ps_dir3");
	
	my $ps_dir3_1 = "4.2_filter_cds_match"; unless(-e "pos_selection/$ps_dir3_1"){system("mkdir -p $pos_selection/$ps_dir3_1");}
	my $ps_dir3_1_1 = "4.2_filter_cds_match_phy"; unless(-e "pos_selection/$ps_dir3_1_1"){system("mkdir -p $pos_selection/$ps_dir3_1_1");}
	unless(-e "$pos_selection/4.2.fa2phy.ok"){
		opendir(DIR, "$pos_selection/$ps_dir3_1") or die $!; my @fastas = grep(/\.fasta$/, readdir(DIR)); close DIR;
		foreach my $fa (sort @fastas){
			my $phy = $fa; $phy =~ s/\.fasta$/.phy/;
			system("perl $main/scripts/Fasta2Phylip.pl $pos_selection/$ps_dir3_1/$fa $pos_selection/$ps_dir3_1_1/$phy") == 0 or die $!;
		}
		open(OUT, ">$pos_selection/4.2.fa2phy.ok") or die "$!";
		close OUT;
	}
	
	my $ps_dir3_2 = "4.2_trimal_filter_cds_match"; unless(-e "pos_selection/$ps_dir3_2"){system("mkdir -p $pos_selection/$ps_dir3_2");}
	my $ps_dir3_3 = "4.2_trimal_refilter_cds_match"; unless(-e "pos_selection/$ps_dir3_3"){system("mkdir -p $pos_selection/$ps_dir3_3");}
	system("perl ./scripts/4.2.match_trim_filter.pl $pos_selection $ps_dir3 $ps_dir3_1 $ps_dir3_2 $ps_dir3_3 $spe_num $cpu"); # trim the unaligned nucleotide
	
	my $cds_merge = "4.3_CDS_merge_tree"; unless(-e "$pos_selection/$cds_merge"){system("mkdir -p $pos_selection/$cds_merge");}
	system("perl ./scripts/4.3.merge_singlecopygenes_phy.pl $pos_selection $cds_merge @species");
	unless(-e "$pos_selection/4.3.merged_cds.tree.ok"){
		chdir("$pos_selection/$cds_merge");
		#system("nohup raxmlHPC-PTHREADS-AVX -T 2 -f a -N 100 --bootstop-perms=1000 -m GTRCATI -x 12345 -p 12345 -o $ref -s merged.aln.phy -n merged.aln.nwk &");#-m GTRCATI，GTRGAMMA for nucleotide,-f 慢速搜索，结果几乎无差异		chdir "../../";	
		system("nohup raxmlHPC-PTHREADS-AVX -T 32 -f a -N 100 --bootstop-perms=1000 -m GTRCATI -x 12345 -p 12345 -o $ref -s merged.aln.phy -n merged.aln.nwk &");#-m GTRCATI，GTRGAMMA for nucleotide,-f 慢速搜索，结果几乎无差异		chdir "../../";	
		chdir "../../";
		open(OUT, ">$pos_selection/4.3.merged_cds.tree.ok") or die "$!";
		close OUT;
	}

	my $ps_dir4 = "4.4_aligned_cds_phy"; unless(-e "$pos_selection/$ps_dir4"){system("mkdir -p $pos_selection/$ps_dir4");}
	system("perl ./scripts/4.4.Reorder_Change_phy_format.pl $pos_selection $ps_dir3_3 $ps_dir4 @species");
	
	unless(-e "$pos_selection/4.4.split_cds.const.ok"){
		opendir(PEPP, "$pos_selection/$ps_dir4") or die "$!";my @cds_phys = grep(/phy/, readdir(PEPP)); close PEPP;
		my $out_tree = "4.4_out_cds_tree";
		unless(-e "$pos_selection/$out_tree"){system("mkdir -p $pos_selection/$out_tree");}
		chdir "$pos_selection/$out_tree";
		open(PA_PC, ">../parafly_run.construct.cds.txt") or die "$!";		
		foreach my $each (sort @cds_phys){
			my $out = $each; $out =~ s/\.phy$/.nwk/;
			print PA_PC "raxmlHPC-PTHREADS-AVX -T 2 -f a -N 100 --bootstop-perms=1000 -m GTRCATI -x 12345 -p 12345 -o $ref -s \"../$ps_dir4/$each\" -n $out\n";
		}
		system("nohup ParaFly -c ../parafly_run.construct.cds.txt -CPU $cpu &");
		chdir "../../";
		open(MPC, ">$pos_selection/4.4.split_cds.const.ok") or die "$!";
		close MPC;
	}

	unless(-e "$pos_selection/4.4.split_cds_noroot.const.ok"){
		opendir(PEPP, "$pos_selection/$ps_dir4") or die "$!";my @cds_phys = grep(/phy/, readdir(PEPP)); close PEPP;
		my $out_tree = "4.4_out_cds_tree_noroot";
		unless(-e "$pos_selection/$out_tree"){system("mkdir -p $pos_selection/$out_tree");}
		chdir "$pos_selection/$out_tree";
		open(PA_PC, ">../parafly_run.construct.cds_noroot.txt") or die "$!";		
		foreach my $each (sort @cds_phys){
			my $out = $each; $out =~ s/\.phy$/.nwk/;
			print PA_PC "raxmlHPC-PTHREADS-AVX -T 1 -f a -N 100 --bootstop-perms=1000 -m GTRCATI -x 12345 -p 12345 -s \"../$ps_dir4/$each\" -n $out\n";
		}
		system("nohup ParaFly -c ../parafly_run.construct.cds_noroot.txt -CPU $cpu && cat RAxML_bestTree.* >../combined.all.tree.txt && java -jar $astral -r 1000 -i ../combined.all.tree.txt -o ../astral.nwk &");
		
		
		chdir "../../";
		open(MPC, ">$pos_selection/4.4.split_cds_noroot.const.ok") or die "$!";
		close MPC;
	}
=pod	
	my $ps_dir5 = "4.5_gblock_aligned_ori"; unless(-e "$pos_selection/$ps_dir5"){system("mkdir -p $pos_selection/$ps_dir5");}
	opendir(A_CDS, "$pos_selection/$ps_dir3_1") or die $!; my @matched_cds = grep(/\.fasta/g, readdir(A_CDS)); close A_CDS;
	chdir "$pos_selection/$ps_dir5";
	open(PA_GB, ">parafly_run.gblocks.txt") or die "$!";	
	foreach my $each (sort @matched_cds){
		my $cmd = "cp ../$ps_dir3_1/$each ./ && Gblocks $each -t=c && rm -rf ./$each";
		print PA_GB "$cmd\n";
	}close PA_GB;
	system("ParaFly -c parafly_run.gblocks.txt -CPU 32") or die $!;
	chdir "../..";
	
	my $ps_dir6 = "4.6_gblock2paml"; unless(-e "$pos_selection/$ps_dir6"){system("mkdir -p $pos_selection/$ps_dir6");}
	opendir(G_CDS, "$pos_selection/$ps_dir5") or die $!; my @matched_gblocks = grep(/\-gb$/, readdir(G_CDS)); close G_CDS;
	chdir "$pos_selection/$ps_dir6";
	open(PA_GBPM, ">parafly_run.gblocks2paml.txt") or die "$!";
	foreach my $each (sort @matched_gblocks){
		my $out = "$each".".paml";
		#print "$out\n";
		system("perl ../../scripts/4.5.Gblocks2Paml.pl ../$ps_dir5/$each $out") == 0 or die $!;
		print PA_GBPM "perl ../../scripts/4.5.Gblocks2Paml.pl ../$ps_dir5/$each $out\n";
	}close PA_GBPM;
	system("ParaFly -c parafly_run.gblocks2paml.txt -CPU 32") or die $!;
	chdir "../..";	
=cut	
	open(OUT, ">$pos_selection/4.prepare.ps.ok") or die "$!";
	close OUT;
}
#=cut




=pod
## the last ones should manually prepared!!!
# step 5: run paml
print "step 5: run paml\n";
my $paml_work = "5.run_ps";
unless(-e "$paml_work"){system("mkdir -p $paml_work");}
unless(-e "$paml_work/5.paml.ok"){
	my $phy_dir = "$pos_selection/4.2_filter_cds_match_phy";
	opendir(DIR, $phy_dir) or die "$!";my @files = grep(/\.phy/, readdir(DIR));close DIR;
	
	my $free = "free_ratio";
	unless(-e "$paml_work/$free"){system("mkdir -p $paml_work/$free");}
	chdir "$paml_work/$free";
	unless(-e "../5.0.free_ratio.ok"){
		open(PA_ST2, ">5.0.parafly_multirun.codeml_free.txt") or die "$!";
		my $codemlfile = "codemlfile";
		unless(-e "$codemlfile"){system("mkdir -p $codemlfile")};
		foreach my $file (@files){
			system("cp ../../configures/codeml_ps.ctl $codemlfile/\"codel.\"$file\".ctl\"");
			system("cp ../../scripts/5.0.Run_CODEML_unroot_free_ratio.pl ./");
			system("cp ../../configures/tree_free_one.txt ./");
			print PA_ST2 "perl 5.0.Run_CODEML_unroot_free_ratio.pl $file tree_free_one.txt $codemlfile/codel.$file.ctl $main/$pos_selection/4.3_aligned_cds_phy\n";
		}
		system("nohup ParaFly -c 5.0.parafly_multirun.codeml_free.txt -CPU 32 &");
		open(OUT, ">../5.0.free_ratio.ok") or die "$!";
		close OUT;
		chdir "../../";		
	}
	
	my $one = "one_ratio";
	unless(-e "$paml_work/$one"){system("mkdir -p $paml_work/$one");}
	chdir "$paml_work/$one";
	unless(-e "../5.0.one_ratio.ok"){
		open(PA_ST2, ">5.0.parafly_multirun.codeml_one.txt") or die "$!";
		my $codemlfile = "codemlfile";
		unless(-e "$codemlfile"){system("mkdir -p $codemlfile")};
		foreach my $file (@files){
			system("cp ../../configures/codeml_ps.ctl $codemlfile/\"codel.\"$file\".ctl\"");
			system("cp ../../scripts/5.0.Run_CODEML_unroot_one_ratio.pl ./");
			system("cp ../../configures/tree_free_one.txt ./");
			print PA_ST2 "perl 5.0.Run_CODEML_unroot_one_ratio.pl $file tree_free_one.txt $codemlfile/codel.$file.ctl $main/$pos_selection/4.3_aligned_cds_phy\n";
		}
		system("nohup ParaFly -c 5.0.parafly_multirun.codeml_one.txt -CPU 32 &");
		open(OUT, ">../5.0.one_ratio.ok") or die "$!";
		close OUT;
		chdir "../../";		
	}
	
	
	my @test_branch = @postive_selection_branch;
	foreach my $each (sort @test_branch){
		unless(-e "$paml_work/$each"){system("mkdir -p $paml_work/$each");}
		
		my $site1 = "site1";
		unless(-e "$paml_work/$each/$site1"){system("mkdir -p $paml_work/$each/$site1");}
		chdir "$paml_work/$each/$site1";
		unless(-e "../5.1.site1.ok"){
			open(PA_ST2, ">5.1.parafly_multirun.codeml_site1.txt") or die "$!";
			my $codemlfile = "codemlfile";
			unless(-e "$codemlfile"){system("mkdir -p $codemlfile")};
			my $tree = "tree_".$site1."_site1.txt";			
			foreach my $file (@files){
				system("cp \"codeml_ps.ctl\" ./$codemlfile/\"codel.\"$file\".ctl\"");
				system("cp ../../../scripts/5.1.Run_CODEML_unroot_branch_site_1.pl ./");
				system("cp ../../../configures/$tree ./");				
				print PA_ST2 "perl Run_CODEML_unroot_branch_site_1.pl $file $tree $codemlfile/codel.$file.ctl $main/$pos_selection/4.3_aligned_cds_phy\n";
			}
			open(OUT, ">$paml_work/5.1.site1.ok") or die "$!";
			close OUT;
			chdir "../../../";
		}
		
		my $site2 = "site2";
		unless(-e "$paml_work/$each/$site2"){system("mkdir -p $paml_work/$each/$site2");}
		chdir "$paml_work/$each/$site2";
		unless(-e "../5.2.site2.ok"){
			open(PA_ST2, ">5.2.parafly_multirun.codeml_site2.txt") or die "$!";
			my $codemlfile = "codemlfile";
			unless(-e "$codemlfile"){system("mkdir -p $codemlfile")};
			my $tree = "tree_".$site2."_site2.txt";
			foreach my $file (@files){
				system("cp \"codeml_ps.ctl\" ./$codemlfile/\"codel.\"$file\".ctl\"");
				system("cp ../../../scripts/5.1.Run_CODEML_unroot_branch_site_2.pl ./");
				system("cp ../../../configures/$tree ./");				
				print PA_ST2 "perl Run_CODEML_unroot_branch_site_2.pl $file $tree $codemlfile/codel.$file.ctl $main/$pos_selection/4.3_aligned_cds_phy\n";
			}
			open(OUT, ">$paml_work/5.2.site2.ok") or die "$!";
			close OUT;
			chdir "../../../";
		}
	}
}




# step 6 dating with mcmctree
print "step 6: dating with mcmctree\n";
my $dating = "6.dating.cds";
unless(-e "$dating"){system("mkdir -p $dating");}
#=pod
# cds
unless(-e "$dating/6.dating.ok"){
	my $mut_rate;
	my $cal_rate = "6.0.cal_mutation_rate";
	unless(-e "$dating/$cal_rate"){system("mkdir -p $dating/$cal_rate");}
	unless(-e "$dating/6.0.mut_rate.ok"){
		chdir "$main/$dating/$cal_rate";
		system("cp $main/4.pre_ps/4.3_CDS_merge_tree/merged.aln.phy ./");
		system("cp $main/configures/cds/model.tree_fossil.nwk ./");
		system("cp $main/configures/cds/baseml.ctl ./");
		system("baseml baseml.ctl");
		chdir "../../";
		open(OUT, ">$dating/6.0.mut_rate.ok") or die "$!"; close OUT;
	}
	
	my $br_gra = "6.1.branch_gra_hes";
	unless(-e "$dating/$br_gra"){system("mkdir -p $dating/$br_gra");}
	unless(-e "$dating/6.1.br_gra_hes.ok"){
		chdir "$main/$dating/$br_gra";
		system("cp $main/4.pre_ps/4.3_CDS_merge_tree/merged.aln.phy ./");
		system("cp $main/configures/cds/model.mcmctree.ctl ./");
		system("cp $main/configures/cds/tree_fossil.nwk ./");
		
		my $a = 1; my $b;	
		open(MLB, "../6.0.cal_mutation_rate/mlb") or die $!;
		while(my $line = <MLB>){
			chomp($line);
			if($line =~ m/^\s+(\S+) \+\- \S+/){
				print "$line\n";
				$mut_rate = $1;
				print "$mut_rate\n";
			}
		}
		close MLB;		
		print "mutation rate: $mut_rate\n";
		$b = 1/$mut_rate; $b = sprintf("%0.2f", $b);
		
		open(MCM, "model.mcmctree.ctl") or die $!;
		open(NMCM, ">new.model.mcmctree.ctl") or die $!;
		while(<MCM>){
			chomp;
			if($_ =~ m/rgene_gamma/g){
				$_ = "\trgene_gamma = $a $b\n";
				print NMCM "$_\n";
			}else{print NMCM "$_\n";}
		}close MCM; close NMCM;
		system("mcmctree new.model.mcmctree.ctl");
		chdir "../../";
		open(OUT, ">$dating/6.1.br_gra_hes.ok") or die "$!";
		close OUT;		
	}
	
	my $cal_date = "6.2.real_dating";
	unless(-e "$dating/$cal_date"){system("mkdir -p $dating/$cal_date");}
	chdir "$dating/$cal_date";
	unless(-e "$main/$dating/6.2.real_dating.ok"){
		system("cp $main/4.pre_ps/4.3_CDS_merge_tree/merged.aln.phy ./");
		system("cp $main/configures/cds/mcmctree.ctl ./");	
		system("cp $main/$dating/$br_gra/rst2 ./in.BV");
		system("cp $main/configures/cds/tree_fossil.nwk ./");
		system("mcmctree ./mcmctree.ctl");
		my $run = "run05"; unless(-e $run){system("mkdir -p $run");}
		system("mv ./* $run/");
		open(OUT, ">$main/$dating/6.2.real_dating.ok") or die "$!";
		close OUT;
	}
	chdir "../../";	
	# mannully run "mcmctree ./mcmctree.ctl", and you need improve the paras: burnin and sampfreq
	open(OUT, ">$dating/6.dating.cds.ok") or die "$!";
	close OUT;
}


=pod
# pep for mcmctree
unless(-e "$dating/6.dating.ok"){
	my $mut_rate;
	my $cal_rate = "6.0.cal_mutation_rate";
	unless(-e "$main/$dating/$cal_rate"){system("mkdir -p $main/$dating/$cal_rate");}
	chdir "$main/$dating/$cal_rate";
	unless(-e "$main/$dating/6.0.mut_rate.ok"){
		system("cp $main/$construct_tree/3.0.pep_merged/trim.merged.aln.phy ./");
		system("cp $main/configures/tree_fossil_mut_rate.nwk ./");
		system("cp $main/configures/codeml_mut_rate.ctl ./");
		system("codeml codeml_mut_rate.ctl");
		open(OUT, ">$main/$dating/6.0.mut_rate.ok") or die "$!";
		close OUT;
	}
	open(MLC, "mlc") or die $!;
	my $i = 0; my $last_line; my %hash_line;
	while(my $line = <MLC>){
		chomp($line); $i++;
		if($i == 1){
			$hash_line{$i} = $line; next;
		}else{
			my $j = $i - 1;
			if($hash_line{$j} =~ m/^Substitution rate is per time unit/){
				$line =~ m/^\s\s\s\s(\S+)/; $mut_rate = $1;
			}else{
				$hash_line{$i} = $line; next;
			}
		}
		#if($line =~ m/^\s\s\s\s(\S+)/){
		#	print "$line\n";
		#	$mut_rate = $1;
		#	print "$mut_rate\n";
		#}
	}
	close MLC;
	chdir "../../";
	
	print "mutation rate: $mut_rate\n";
	my $a = 1;
	my $b = 1/$mut_rate; $b = sprintf("%0.2f", $b);
	
	my $br_gra = "6.1.branch_gra_hes";
	unless(-e ""){system("mkdir -p $dating/$br_gra");}
	chdir "$main/$dating/$br_gra";	
	unless(-e "$main/$dating/6.1.br_gra_hes.ok"){
		system("cp $main/$construct_tree/3.0.pep_merged/trim.merged.aln.phy ./");
		system("cp $main/configures/model.mcmctree.ctl ./");
		system("cp $main/configures/tree_fossil.nwk ./");
		open(MCM, "model.mcmctree.ctl") or die $!;
		open(NMCM, ">new.model.mcmctree.ctl") or die $!;
		while(<MCM>){
			chomp;
			if($_ =~ m/rgene_gamma/g){
				$_ = "\trgene_gamma = $a $b\n";
				print NMCM "$_\n";
			}else{print NMCM "$_\n";}
		}close MCM; close NMCM;
		system("mcmctree ./new.model.mcmctree.ctl");
		open(OUT, ">$main/$dating/6.1.br_gra_hes.ok") or die "$!";
		close OUT;		
	}
	chdir "../../";
	
	my $cal_date = "6.2.real_dating";
	unless(-e "$dating/$cal_date"){system("mkdir -p $dating/$cal_date");}
	chdir "$dating/$cal_date";
	unless(-e "$main/$dating/6.2.real_dating.ok"){
		system("cp $main/$construct_tree/3.0.pep_merged/trim.merged.aln.phy ./");
		system("cp $main/configures/mcmctree.ctl ./");	
		system("cp $main/$dating/$br_gra/rst2 ./in.BV");
		system("cp $main/configures/tree_fossil.nwk ./");
		system("mcmctree ./mcmctree.ctl");
		my $run01 = "run01"; unless(-e "run01"){system("mkdir -p $run01");}
		system("mv FigTree.tre mcmc.out out SeedUsed $run01/");
		open(OUT, ">$main/$dating/6.2.real_dating.ok") or die "$!";
		close OUT;
	}
	# mannully run "mcmctree ./mcmctree.ctl", and you need improve the paras: burnin and sampfreq
	open(OUT, ">$main/$dating/6.dating.ok") or die "$!";
	close OUT;
	chdir "../../";
}
=cut

=pod
# mannually setup the cafe configures with tree file
# step 7: gene family expansion and contraction;
# python2 env
print "step 7: gene family expansion and contraction\n";

my $exp_contra = "7.expansion_contraction";
unless(-e ""){system("mkdir -p $exp_contra");}
chdir "$exp_contra";
unless(-e "$exp_contra/7.gene_fam_exp_contra.ok"){
	my $pre_cafe = "7.0.filter_input"; unless(-e $pre_cafe){system("mkdir -p $pre_cafe");} 
	chdir "$pre_cafe";
	system("cp $main/$orth_work/Results*/Orthogroups/Orthogroups.GeneCount.tsv ./");
	my $cmd = qq(awk 'OFS="\t" {$NF=""; print}' Orthogroups.GeneCount.tsv > tmp && awk '{print "(null)""\t"$0}' tmp > cafe.input.tsv && sed -i '1s/(null)/Desc/g' cafe.input.tsv && rm tmp");
	system($cmd);
	system("python $main/scripts/cafetutorial_clade_and_size_filter.py -i cafe.input.tsv -o filtered_cafe_input.txt -s 2> filtered.log");
	chdir "../";
	
	my $run_cafe = "7.1.run_cafe"; unless(-e $run_cafe){system("mkdir -p $run_cafe");}
	chdir "$run_cafe";
	system("cp .../$pre_cafe/filtered_cafe_input.txt ./");
	system("sed -i 's/\.pep//g' filtered_cafe_input.txt");
	system("cp $main/configures/cafetutorial_run1.sh ./");
	unless(-e "reports"){system("mkdir -p reports");}
	system("cafe cafe_run1.sh") or die "$!";
	system("python $main/scripts/cafetutorial_report_analysis.py -i reports/report_run1.cafe -o reports/summary_run1");# -s default is 100, you can specific this, but less than 200
	my $cafe_type = ("Expansions", "Contractions", "Rapid");
	my $tree_nwk;
	open(TREE, "") or die "$!";
	while(my $line = <TREE>){
		chomp($line);
		$line =~ s/\;$//; $tree_nwk = $line;
	}close TREE;
	my $node;
	open(ND, "./reports/summary_run1_fams.txt") or die $!;
	while(my $line = <ND>){
		chomp($line);
		if($line =~ m/^\# The/){
			my @arr = split(/\s+/, $line); $node = $arr[-1];
		}
	}close ND;
	foreach my $each (@cafe_type){
		system("python $main/scripts/cafetutorial_draw_tree.py -i ./reports/summary_run1_node.txt -t \"$tree\" -d \"$node\" -o summary_run1_tree_$each.png -y $each");
	}
	chdir "../../"
	
	open(OUT, ">$main/$exp_contra/7.gene_fam_exp_contra.ok") or die "$!";
	close OUT;	
}
=cut