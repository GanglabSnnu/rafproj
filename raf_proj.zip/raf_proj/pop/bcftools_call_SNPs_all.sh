ref="/data-storage/Public/yjq/bats_proj/pop_update/01.ref/AG_Roa/Roa_genome.fasta"
bam="/data-storage/Public/yjq/bats_proj/pop_update/03.bam/AG_Roa"
species="Roa"

bcftools mpileup -Ou -C50 -Q30 -I -f $ref $bam/*_sort_rmdup.bam | bcftools call -mv -Ou | bcftools view -U -m2 -M2  > $species.raw.vcf


