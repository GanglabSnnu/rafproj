def load_name_list(name_file):
    nameList = []
    with open(name_file) as f:
        for name in f:
            nameList.append(name.strip())
    return nameList


def produce(nameList):
    for n,i in enumerate(nameList):
        for chrom in list(range(1,31)) + ["X", "Y"]:
                print(i, chrom)
                with open('%s_%s_gv.sh' % (i, chrom),'w') as f:
                    f.write('''#!/bin/sh
        export ref=/data-storage/Public/yjq/bats_proj/pop_update/01.ref/ZJ_Rha/BAT_chr_rename.fasta
		export BAM=/data-storage/Public/yjq/bats_proj/pop_update/03.bam/MT_Rhf/bam/02.sort_dum_bam
		export GVCF=/data-storage/Public/yjq/bats_proj/pop_update/04.snp/01.gvcf
        ''')
                    f.write('''
        java -Djava.io.tmpdir=/data-storage/Public/yjq/bats_proj/pop_update/00.temp -Xmx40g -jar /home/yjq/anaconda3/envs/gatk3.8/opt/gatk-3.8/GenomeAnalysisTK.jar \\
		-T HaplotypeCaller \\
		-R $ref \\
		-ERC GVCF \\
		-variant_index_type LINEAR \\
		-variant_index_parameter 128000 \\
		-nct 8 \\
		-L {chrom} \\
		-I $BAM/{ID}.dedup.bam \\
		-o $GVCF/{chrom}_{ID}.g.vcf.gz 
        echo "gvcf is done"
        '''.format(ID=i, chrom=chrom))

def main():
    import sys
    print(sys.argv)
    nameList = load_name_list(sys.argv[1])
    produce(nameList)
main()

