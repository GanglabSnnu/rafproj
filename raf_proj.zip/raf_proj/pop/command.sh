#!/bin/bash
/home/yjq/anaconda3/bin/smartpca -p ZJ_eigensoft_smartpca.par
