#!/bin/sh
export ref=/data-storage/Public/yjq/bats_proj/pop_update/01.ref/ZJ_Rha/BAT_chr_rename.fasta
export GVCF1=/data-storage/Public/yjq/bats_proj/pop_update/04.SNP/01.gvcf
export GVCF2=/data-storage/Public/yjq/bats_proj/pop_update/04.snp/02.merge_gvcf/01.cmd
export GVCF3=/data-storage/Public/yjq/bats_proj/pop_update/04.snp/02.merge_gvcf

java -Djava.io.tmpdir=/data-storage/Public/yjq/bats_proj/pop_update/00.temp -Xmx40g -jar /home/yjq/anaconda3/envs/gatk3.8/opt/gatk-3.8/GenomeAnalysisTK.jar \
		-R $ref \
		-T CombineGVCFs \
		--variant $GVCF2/1.list \
		-o $GVCF3/1.merge.g.vcf.gz
