#!/bin/bash
ref="Rhs_genome.fasta"
PICARD="/data-storage/Public/yjq/bats_proj/pop_update/softwear/picard/picard.jar"

bwa index -a bwtsw $ref

samtools faidx $ref

java -jar $PICARD CreateSequenceDictionary R=$ref O=Rhs_genome.dict
