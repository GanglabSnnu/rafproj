vcftools --gzvcf /data-storage/Public/yjq/bats_proj/pop_update/04.SNP/05.catall/Without_sex_chr/ZJ.vcf.gz \
--plink --chrom-map chrID  --out ZJ
plink --file ZJ --chr-set 30  --make-bed  --out ZJ

