#!/bin/sh
export ref=/data-storage/Public/yjq/bats_proj/pop_update/01.ref/ZJ_Rha/BAT_chr_rename.fasta
export Genotype=/data-storage/Public/yjq/bats_proj/pop_update/04.snp/03.genotype

java -Djava.io.tmpdir=/data-storage/Public/yjq/bats_proj/pop_update/00.temp -Xmx40g -jar /home/yjq/anaconda3/envs/gatk3.8/opt/gatk-3.8/GenomeAnalysisTK.jar \
        -R $ref \
        -T GenotypeGVCFs \
        --variant /data-storage/Public/yjq/bats_proj/pop_update/04.snp/02.merge_gvcf/1.merge.g.vcf.gz \
		-o $Genotype/1.vcf.gz \
		--disable_auto_index_creation_and_locking_when_reading_rods \
		--includeNonVariantSites \
		-stand_call_conf 10 
