vcftools \
--vcf Roa.raw.vcf \
--minDP 4 \
--maxDP 100 \
--minQ 30 \
--recode \
--recode-INFO-all \
--maf 0.05 \
--out Roa.clean
