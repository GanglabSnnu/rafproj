vcftools --gzvcf /data-storage/Public/yjq/bats_proj/pop_update/04.snp/05.catall/Without_sex_chr/ZJ.vcf.gz \
--keep /data-storage/Public/yjq/bats_proj/pop_update/05.analysis/05.seletion/00.pop/ZJ9 \
--window-pi 50000 \
--window-pi-step 25000 \
--out  ZJ9.pi