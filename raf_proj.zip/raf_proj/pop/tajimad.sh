vcftools --gzvcf /data-storage/Public/yjq/bats_proj/pop_update/04.snp/05.catall/Without_sex_chr/ZJ.vcf.gz \
--keep /data-storage/Public/yjq/bats_proj/pop_update/05.analysis/05.seletion/00.pop/ZJ9 \
--TajimaD 50000 \
--out ZJ9
