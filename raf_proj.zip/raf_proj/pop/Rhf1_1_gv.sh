#!/bin/sh
        export ref=/data-storage/Public/yjq/bats_proj/pop_update/01.ref/ZJ_Rha/BAT_chr_rename.fasta
		export BAM=/data-storage/Public/yjq/bats_proj/pop_update/03.bam/MT_Rhf/bam/02.sort_dum_bam
		export GVCF=/data-storage/Public/yjq/bats_proj/pop_update/04.snp/01.gvcf
        
        java -Djava.io.tmpdir=/data-storage/Public/yjq/bats_proj/pop_update/00.temp -Xmx40g -jar /home/yjq/anaconda3/envs/gatk3.8/opt/gatk-3.8/GenomeAnalysisTK.jar \
		-T HaplotypeCaller \
		-R $ref \
		-ERC GVCF \
		-variant_index_type LINEAR \
		-variant_index_parameter 128000 \
		-nct 8 \
		-L 1 \
		-I $BAM/Rhf1.dedup.bam \
		-o $GVCF/1_Rhf1.g.vcf.gz 
        echo "gvcf is done"
        