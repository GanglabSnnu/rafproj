#!/bin/sh
~/anaconda3/envs/gatk3.8/bin/vcftools --gzvcf /data-storage/Public/yjq/bats_proj/pop_update/04.snp/01.no_masked/05.catall/Without_sex_chr/ZJ.vcf.gz \
--weir-fst-pop /data-storage/Public/yjq/bats_proj/pop_update/05.analysis/05.seletion/00.pop/ZJ9 \
--weir-fst-pop /data-storage/Public/yjq/bats_proj/pop_update/05.analysis/05.seletion/00.pop/ZJ12 \
--fst-window-size 50000 \
--fst-window-step 25000 \
--out ZJ_fst
